package pokemon_edim;

public class Main {

    public static void main(String[] args) {
		
    	
		Joc.importarArxius(); 
	    }
	}



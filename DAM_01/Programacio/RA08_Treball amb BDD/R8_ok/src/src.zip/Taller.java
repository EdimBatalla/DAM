import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Taller {

	private ArrayList<Client> clients;
	
	public Taller() {
		this.clients = new ArrayList<>();
	}

	public ArrayList<Client> getClients() {
		return clients;
	}

	public void setClients(ArrayList<Client> clients) {
		this.clients = clients;
	}

	public void agefirClients(Client client) {
		this.clients.add(client);
	}

	public ArrayList<Client> consultarClients() {
		return this.clients;
	}

	public void eliminarClient(Client client) {
		this.clients.remove(client);
	}

	public int comptarClients() {
		return this.clients.size();
	}

	public void afegirReparacio(Cotxe cotxe, Reparacio reparacio) {
		cotxe.getReparacions().add(reparacio);
	}
	
	public void toStringReparacio(Cotxe cotxe) {
		for (Reparacio reparacio : cotxe.getReparacions()) {
			System.out.println(reparacio.toString());
		}
	}
	
	public void carregarClientsDesDeBD() {
	    ArrayList<Client> llista = new ArrayList<>();

	    String sql = "SELECT id_client, nom, telefon FROM clients";

	    try (Connection conn = GestorBD.connectar();
	         PreparedStatement stmt = conn.prepareStatement(sql);
	         ResultSet rs = stmt.executeQuery()) {

	        while (rs.next()) {
	            int id = rs.getInt("id_client");
	            String nom = rs.getString("nom");
	            String telefon = rs.getString("telefon");

	            Client c = new Client(id, nom, telefon); //  carrega també cotxes dins el constructor
	            llista.add(c);
	        }

	        this.clients = llista;

	    } catch (SQLException e) {
	        System.err.println("Error en carregar els clients: " + e.getMessage());
	    }
	}
}

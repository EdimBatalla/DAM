import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class GestorBD {
    private static Connection connexio;

    public static Connection connectar() {
        if (connexio != null) return connexio;

        String url = "jdbc:mysql://localhost:3306/taller";
        String usuari = "root";
        String contrasenya = "bemen3"; 
        try {
            connexio = DriverManager.getConnection(url, usuari, contrasenya);
            System.out.println("Connexió correcta a la BDD.");
        } catch (SQLException e) {
            System.err.println("Error en la connexió: " + e.getMessage());
        }

        return connexio;
    }

    public static Connection getConnexio() {
        return connexio;
    }
}

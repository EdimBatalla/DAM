import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

public class PantallaTaller {
    private Taller taller;
    private ScreenManager screenManager;

    public PantallaTaller(Taller taller, ScreenManager screenManager) {
        this.taller = taller;
        this.screenManager = screenManager;

    }

    public Parent getView() {
        BorderPane root = new BorderPane();

        //Botons superiors
        Button btnClients = new Button("Clients");
        btnClients.setOnAction(e -> screenManager.setPantalla(new PantallaClients(taller, screenManager).getView()));

        Button btnCotxes = new Button("Cotxes");
        btnCotxes.setOnAction(e -> screenManager.setPantalla(new PantallaCotxesGeneral(taller, screenManager).getView()));

        Button btnReparacions = new Button("Reparacions");
        btnReparacions.setOnAction(e -> screenManager.setPantalla(new PantallaReparacionsGeneral(taller, screenManager).getView()));

        Button btnResum = new Button("Resum");
        btnResum.setOnAction(e -> screenManager.setPantalla(new PantallaResum(taller, screenManager).getView()));

        Button btnSortir = new Button("Sortir");
        btnSortir.setOnAction(e -> root.getScene().getWindow().hide());

        HBox botoBox = new HBox(20, btnClients, btnCotxes, btnReparacions, btnResum, btnSortir);
        botoBox.setAlignment(Pos.CENTER);
        botoBox.setPadding(new Insets(60, 20, 20, 20));

        root.setTop(botoBox);

        //Imatge centrada verticalment al centre
        Image image = new Image("file:mecanic.jpg"); // Assegura't que el fitxer existeix
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(500);
        imageView.setPreserveRatio(true);

        VBox imageBox = new VBox(imageView);
        imageBox.setAlignment(Pos.CENTER);
        imageBox.setPadding(new Insets(20));

        root.setCenter(imageBox); // La imatge ocupa el centre

        return root;
    }


}

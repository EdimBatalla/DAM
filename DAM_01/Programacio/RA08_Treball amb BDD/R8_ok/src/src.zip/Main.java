import javafx.application.Application;
import javafx.stage.Stage;
import java.sql.Connection;

public class Main extends Application {

	@Override
	public void start(Stage primaryStage) {
	    Connection connexio = GestorBD.connectar();
	    if (connexio == null) {
	        System.err.println("No s'ha pogut connectar a la base de dades.");
	        return;
	    }

	    Taller taller = new Taller();
	    taller.carregarClientsDesDeBD(); 
	    System.out.println("Clients carregats: " + taller.comptarClients());
	    
	    ScreenManager screenManager = new ScreenManager(primaryStage);
	    PantallaInici pantallaInici = new PantallaInici(taller, screenManager);
	    screenManager.setPantalla(pantallaInici.getView());
	    primaryStage.setTitle("Entrar al Taller");
	    primaryStage.show();
	}

    public static void main(String[] args) {
        launch(args);
    }
}

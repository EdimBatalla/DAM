import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Cotxe {

	private String matricula;
	private String marca;
	private String model;
	private String any;
	private ArrayList<Reparacio> reparacions;

	// Constructor
	public Cotxe(String matricula, String model, String marca, String any) {
		this.matricula = matricula;
		this.model = model;
		this.marca = marca;
		this.any = any;
		this.reparacions = new ArrayList<>();
	}

	// Getters i setters

	@Override
	public String toString() {
		return "Matrícula: " + matricula + " | Marca: " + marca + " | Model: " + model + " | Any: " + any;
	}

	public void afegirReparacio(Reparacio reparacio) {
		reparacions.add(reparacio);
	}

	// Mètode per obtenir cotxes per client
	public static ArrayList<Cotxe> obtenirCotxesPerClient(int idClient) {
		ArrayList<Cotxe> cotxes = new ArrayList<>();
		String sql = "SELECT matricula, model, marca, any_fabricacio FROM cotxes WHERE id_client = ?";

		try (Connection conn = GestorBD.connectar();
		     PreparedStatement stmt = conn.prepareStatement(sql)) {

			stmt.setInt(1, idClient);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				String matricula = rs.getString("matricula");
				String model = rs.getString("model");
				String marca = rs.getString("marca");
				String any = rs.getString("any_fabricacio");

				Cotxe cotxe = new Cotxe(matricula, model, marca, any);
				cotxes.add(cotxe);
			}
		} catch (SQLException e) {
			System.err.println("Error al carregar cotxes del client: " + e.getMessage());
		}
		return cotxes;
	}
}
